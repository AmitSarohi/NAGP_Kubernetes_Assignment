## Create the replica set
kubectl apply -f ReplicaSet\replicaset-definition.yaml

## Get all the replica set
kubectl get replicaset

## update the replica set; update the replicas to 4 and show them how it is updated 
kubectl replace -f ReplicaSet\replicaset-defination.yaml

## Describe the replica set
kubectl describe replicaset myapp-replicaset

## try deleting a pod and see how replica set take care of managing the replicas of the pod
kubectl delete pod  myapp-replicaset-<id>

## Delete replica set
kubectl delete -f ReplicaSet\replicaset-defination.yaml
kubectl delete replicaset myapp-replicaset