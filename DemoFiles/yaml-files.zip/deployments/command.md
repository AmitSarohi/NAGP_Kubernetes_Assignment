## create the deployment
kubectl apply -f Deployment\deployment-definition.yaml

## list all the deployment
kubectl get all
kubectl get deployments

## decribe deployment
kubectl describe deployment myapp-deployment

## delete deployment
kubectl delete -f Deployment\deployment-definition.yaml

## ################
## Recreate Pattern
## ################
## Apply the deployment
kubectl apply -f Deployment\nginx-recreate-1.yaml
## See the deployment details
kubectl describe Deployment nginx-recreate-deployment
## See the replica set details created in deployment
kubectl describe replicaset nginx-recreate-deployment-<id>  -- take this from the describe deployment command
## Apply updated deployment with updated image
kubectl apply -f Deployment\nginx-recreate-2.yaml
## See the deployment details
kubectl describe Deployment nginx-recreate-deployment
## Get all the replicaset
kubectl get replicaset --> we can see both the replica set
## To know the status of the deployment
kubectl rollout status deployment nginx-recreate-deployment
## TO know the history of the deployment
kubectl rollout history deployment nginx-recreate-deployment
## Try deleting a pod and see it is getting scalled automatically
kubectl delete pod nginx-recreate-pod-<guid>
## try running the deployment with invalid image
kubectl apply -f Deployment\nginx-recreate-3.yaml -- has invalid image
kubectl get all
- see the deployment
- see the replica set
- see the pods -> there will be error
## see the status and the history of the deployment
## rollout the deployment --  will roll back to the previous version
kubectl rollout undo deployment nginx-recreate-deployment  --to-revision 1
kubectl delete deployment [deployment-name]
## Set the change cause
kubectl annotate deployments.apps nginx-recreate-deployment kubernetes.io/change-cause="first 12 crratetd"


## ######################
## Rolling update Pattern
## ######################
## Apply the deployment
kubectl apply -f Deployment\nginx-rolling-update-1.yaml
## See the deployment details
kubectl describe deployment nginx-rolling-update-deployment
## Apply the new deployment with new image
kubectl apply -f Deployment\nginx-rolling-update-2.yaml
## See the deployment details
kubectl describe deployment nginx-rolling-update-deployment
kubectl get pods
## try running the deployment with invalid image
kubectl apply -f Deployment\nginx-rolling-update-3.yaml -- have invalid image
kubectl get all
-- Old Pods will be running
## once deployment are done better to delete the deployments
kubectl delete deployment nginx-recreate-deployment
kubectl delete deployment nginx-rolling-update-deployment