## get all nodes in the cluster in order to check their ip
kubectl get nodes -o wide

## connect to pod
kubectl exec -it <pod-name> -- /bin/bash
or
kubectl exec -it <pod-name> -- /bin/sh

## install curl
apt-get install iputils-ping

## get all installed pods in the system
kubectl get pods -o wide
The pod ip is internal to the node; so i can access the pod from the node1 but not from node2.

## connect to the node who has active pod running on it and the try running the command
wget http://<internalip>:80
cat index.html
-- Thing is that this is not the ideal way. That to access the pod i need to ssh to the node where it is installed. There too i am using IP of POD to connect. As POD are not persistent so everytime i should be aware of the new IP of the POD. The POD cannot be accessed from the outside world directly as right now it is internal to the node.

##### #############
##### NODE PORT -- it is defined for the accessing pod via node ip. Range is 30000-32768
##### #############
kubectl apply -f Services\nginx-nodeport-service.yaml
kubectl get services
kubectl describe service nginx-nodeport-service

go the node and try accessing the port using local host:
wget http://localhost:30080

trying accessing from other node using the current node internal IP
we wont be able to access using external ip as on clouds the port are blocked; they are not open so we wont be able to connect using the external ip for that node. But once we have open that port we can definately use it

To open the port to the external work we need to set the firewal rule for this port.
-VPC Network > Firewall> Create firewall rule
-entername
-target: specified target tags
-target tags:node network tag; get from vm
-source ipv4 range:0.0.0.0/0
-Check tcp and put the port as 30080

gcloud compute firewall-rules create test-node-port --allow tcp:30080

## Delete the service
kubectl delete -f Services\nginx-nodeport-service.yaml

##### #############
##### Cluster IP -- it is defined for the cluster
##### Enabling to connect to the ports with in the cluster without using the POD ips as we can have multiple type of identical pods
##### #############
kubectl apply -f Services\nginx-clusterip-service.yaml
kubectl get services
kubectl describe service nginx-clusterip-service

-- we can connect using ip or cluster ip name; kubernetes will map the name with the ip automatically
>ssh to any node
>>wget http://<clusterip>:80
we can access the servie using the cluster ip but from node we cannot use the cluster service name
only pod will be able to resolve the service name with the ip; it wont be possible using node

> execute the commands from the pod
kubectl exec -it nginx-pod  -- bin/bash
curl http://<clusterip>:80
curl http://nginx-clusterip-service/

kubectl delete -f Services\nginx-clusterip-service.yaml

##### #############
##### LoadBalancer Service
##### #############
kubectl apply -f Services\nginx-lb-service.yaml
kubectl get services
-- show them on the ui and once all service are up acces using the external ip


kubectl delete -f Services\nginx-lb-service.yaml